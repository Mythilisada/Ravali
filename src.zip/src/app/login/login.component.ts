import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { supplierusermodel } from '../supplierusermodel';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  onLoginButton:FormGroup;
  private user:supplierusermodel
  ;
  constructor(private service: ServiceService, private router: Router) { }
 
   //private user1 : usermodel;

  show : boolean = true;
  check : boolean ;
  onConfirmedButton: FormGroup;

   
   ngOnInit() {
     this.onLoginButton = new FormGroup({
       supplierId : new FormControl("",[Validators.required]),
       password : new FormControl("",[Validators.required]),
       
     })
     
   }
  
  
 
   onLogin(userId, password)
   {
     this.service.onlogin(userId,password).subscribe(data=>this.user =data)
    if(this.user.supplierId==userId && this.user.password==password){
      
       this.router.navigate(['/supplierhome'])
     }
    else
    alert("please register")
   }
 
  
 
 
 
 
}
