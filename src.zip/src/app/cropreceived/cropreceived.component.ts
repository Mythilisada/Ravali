import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cropreceived',
  templateUrl: './cropreceived.component.html',
  styleUrls: ['./cropreceived.component.css']
})
export class CropreceivedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
