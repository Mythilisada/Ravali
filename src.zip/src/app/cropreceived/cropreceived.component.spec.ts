import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CropreceivedComponent } from './cropreceived.component';

describe('CropreceivedComponent', () => {
  let component: CropreceivedComponent;
  let fixture: ComponentFixture<CropreceivedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CropreceivedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CropreceivedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
