export class supplierusermodel{
    supplierId:number;
    supplierName:string;
    address:string;
    mobileNo:string;
    password:string;
}