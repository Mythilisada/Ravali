import { Component, OnInit } from '@angular/core';
import { supplierusermodel } from '../supplierusermodel';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerform:FormGroup
  user:supplierusermodel
  constructor(private router:Router,private service:ServiceService) { 
   
  }

  ngOnInit() {
    this.registerform = new FormGroup({
      supplierId:new FormControl("",[Validators.required,Validators.pattern("")]),
    supplierName:new FormControl("",[Validators.required,Validators.pattern("")]),
    address:new FormControl("",[Validators.required,Validators.pattern("")]),
    mobileNo:new FormControl("",[Validators.required,Validators.pattern("^([\+0]91)?\-?[7-9]{1}[0-9]{9}$")]),
    password:new FormControl("",[Validators.required,Validators.pattern("^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$")]),
     
     
     
    })

  }

  onReg(){
    this.service.addSupplieruser(this.registerform.value).subscribe(
      (response:supplierusermodel)=>{
  console.log("response received from server",response)
  this.user=response;
  alert("userId:"+this.user.supplierId+" registered successfully")
    // alert('signed up successfully....')
     this.router.navigate([''])
    }
    )
    }
    back(){
      this.router.navigate([''])
    }
    


  

}
