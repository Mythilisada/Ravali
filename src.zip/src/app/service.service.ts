import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { supplierusermodel } from './supplierusermodel';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
 
  
  

  constructor(private http: HttpClient) { }
  addSupplieruser(user) {
    let opt = new HttpHeaders({'Content-Type':'application/json'})
    return this.http.post('http://localhost:8082/createuser',user,{headers:opt})
 
  }
  onlogin(userid, password){
    return this.http.get<supplierusermodel>('http://localhost:8082/login/'+userid+'/'+password);
  }
}
