import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplierhome',
  templateUrl: './supplierhome.component.html',
  styleUrls: ['./supplierhome.component.css']
})
export class SupplierhomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
