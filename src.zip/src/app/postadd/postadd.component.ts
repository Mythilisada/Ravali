import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postadd',
  templateUrl: './postadd.component.html',
  styleUrls: ['./postadd.component.css']
})
export class PostaddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
