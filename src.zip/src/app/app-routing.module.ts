import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { PostaddComponent } from './postadd/postadd.component';
import { CropreceivedComponent } from './cropreceived/cropreceived.component';
import { LogoutComponent } from './logout/logout.component';


const routes: Routes = [
  { path: "", component: LoginComponent },
{ path: 'register', component: RegisterComponent },
{path: 'postadd', component:PostaddComponent},
{path: 'cropreceived', component:CropreceivedComponent},
{path: 'logout', component:LogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
