package com.farm.capg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmAssistanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
