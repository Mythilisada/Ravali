package com.farm.capg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.farm.capg.dao.SupplierRepository;
import com.farm.capg.model.SupplierUser;


@RestController
public class SupplierService {

	@Autowired
	SupplierRepository supplierRepo;
	public SupplierUser createSupplierUser(SupplierUser user) {
		
		return supplierRepo.save(user);
	}
	public SupplierUser login(int userid, String password) {
		
		return supplierRepo.findBySupplierIdAndPassword(userid, password);
	}

}
