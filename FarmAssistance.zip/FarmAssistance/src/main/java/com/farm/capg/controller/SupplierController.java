package com.farm.capg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.farm.capg.model.SupplierUser;
import com.farm.capg.service.SupplierService;


@CrossOrigin
public class SupplierController {
	@Autowired
	SupplierService service;
	
	@PostMapping("/register")
	public SupplierUser createSupplierUser(@RequestBody SupplierUser user) {
		return service.createSupplierUser(user);
	}
	@GetMapping("/login/{userid}/{password}")
	 public SupplierUser login(@PathVariable int userid, @PathVariable String password)
	 {
	 	return service.login(userid,password);
	 	
	 }

}

