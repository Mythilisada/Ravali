package com.farm.capg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class SupplierUser {
	@Id
	@SequenceGenerator(name = "accNum_seq",sequenceName = "accNum_seq",initialValue = 1000,allocationSize = 1)
	@GeneratedValue(generator = "accNum_seq")
	
	private int supplierId;
	private String supplierName;
	private String address;
	private String mobileNo;
	private String password;
	public SupplierUser(String supplierName, String address, String mobileNo, String password) {
		super();
		this.supplierName = supplierName;
		this.address = address;
		this.mobileNo = mobileNo;
		this.password = password;
	}
	public int getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
